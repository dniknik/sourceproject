--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.ware DROP CONSTRAINT ware_pkey;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_pkey;
ALTER TABLE ONLY public.tree_product DROP CONSTRAINT tree_product_pkey;
ALTER TABLE ONLY public.tree_item DROP CONSTRAINT tree_item_pkey;
ALTER TABLE ONLY public.tree_full DROP CONSTRAINT tree_full_pkey;
ALTER TABLE ONLY public.tree_attribute DROP CONSTRAINT tree_attribute_pkey;
ALTER TABLE ONLY public.sys_tree DROP CONSTRAINT sys_tree_pkey;
ALTER TABLE ONLY public.sys_session DROP CONSTRAINT sys_session_pkey;
ALTER TABLE ONLY public.product DROP CONSTRAINT product_pkey;
ALTER TABLE ONLY public."order" DROP CONSTRAINT order_pkey;
ALTER TABLE ONLY public.order_line DROP CONSTRAINT order_line_pkey;
ALTER TABLE ONLY public.objoftree DROP CONSTRAINT objoftree_pkey;
ALTER TABLE ONLY public.lmb_cms_user DROP CONSTRAINT lmb_cms_user_pkey;
ALTER TABLE ONLY public.preference DROP CONSTRAINT id;
ALTER TABLE ONLY public.category DROP CONSTRAINT category_pkey;
ALTER TABLE public.tree_product ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tree_order_line ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tree_order ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tree_item ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tree_full ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tree_attribute ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.preference ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.objoftree ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.lmb_cms_text_block ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.lmb_cms_seo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.lmb_cms_document ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.ware;
DROP SEQUENCE public.ware_id_seq;
DROP TABLE public."user";
DROP SEQUENCE public.tree_product_id_seq;
DROP TABLE public.tree_product;
DROP SEQUENCE public.tree_order_line_id_seq;
DROP TABLE public.tree_order_line;
DROP SEQUENCE public.tree_order_id_seq;
DROP TABLE public.tree_order;
DROP SEQUENCE public.tree_item_id_seq;
DROP TABLE public.tree_item;
DROP SEQUENCE public.tree_full_id_seq;
DROP TABLE public.tree_full;
DROP SEQUENCE public.tree_attribute_id_seq;
DROP TABLE public.tree_attribute;
DROP TABLE public.sys_tree;
DROP SEQUENCE public.sys_tree_id_seq;
DROP TABLE public.sys_session;
DROP TABLE public.product;
DROP SEQUENCE public.product_id_seq;
DROP SEQUENCE public.preference_id_seq;
DROP TABLE public.preference;
DROP TABLE public.order_line;
DROP TABLE public."order";
DROP SEQUENCE public.objoftree_id_seq;
DROP TABLE public.objoftree;
DROP SEQUENCE public.lmb_cms_user_id_seq;
DROP TABLE public.lmb_cms_user;
DROP SEQUENCE public.user_id_seq;
DROP SEQUENCE public.lmb_cms_text_block_id_seq;
DROP TABLE public.lmb_cms_text_block;
DROP SEQUENCE public.lmb_cms_seo_id_seq;
DROP TABLE public.lmb_cms_seo;
DROP SEQUENCE public.lmb_cms_document_id_seq;
DROP TABLE public.lmb_cms_document;
DROP TABLE public.category;
DROP SEQUENCE public.category_id_seq;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: mail4testy
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO mail4testy;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: mail4testy
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: category_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_id_seq OWNER TO mail4testy;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: category; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE category (
    id integer DEFAULT nextval('category_id_seq'::regclass) NOT NULL,
    title character varying(255) DEFAULT NULL::character varying,
    descr text,
    identifier character varying(128) DEFAULT ''::character varying NOT NULL,
    date_created timestamp without time zone DEFAULT now() NOT NULL,
    date_modified timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.category OWNER TO mail4testy;

--
-- Name: lmb_cms_document; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE lmb_cms_document (
    title character varying(255) DEFAULT ''::character varying NOT NULL,
    description character varying(255) DEFAULT ''::character varying NOT NULL,
    keywords character varying(255) DEFAULT ''::character varying NOT NULL,
    content text,
    is_published integer DEFAULT 0,
    parent_id integer DEFAULT 0 NOT NULL,
    level integer DEFAULT 0 NOT NULL,
    identifier character varying(128) DEFAULT ''::character varying NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    path character varying(255) DEFAULT ''::character varying NOT NULL,
    ctime integer DEFAULT 0 NOT NULL,
    utime integer DEFAULT 0 NOT NULL,
    id integer NOT NULL
);


ALTER TABLE public.lmb_cms_document OWNER TO mail4testy;

--
-- Name: lmb_cms_document_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE lmb_cms_document_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lmb_cms_document_id_seq OWNER TO mail4testy;

--
-- Name: lmb_cms_document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mail4testy
--

ALTER SEQUENCE lmb_cms_document_id_seq OWNED BY lmb_cms_document.id;


--
-- Name: lmb_cms_seo; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE lmb_cms_seo (
    url character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    keywords text NOT NULL,
    id integer NOT NULL
);


ALTER TABLE public.lmb_cms_seo OWNER TO mail4testy;

--
-- Name: lmb_cms_seo_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE lmb_cms_seo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lmb_cms_seo_id_seq OWNER TO mail4testy;

--
-- Name: lmb_cms_seo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mail4testy
--

ALTER SEQUENCE lmb_cms_seo_id_seq OWNED BY lmb_cms_seo.id;


--
-- Name: lmb_cms_text_block; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE lmb_cms_text_block (
    identifier character varying(255) DEFAULT NULL::character varying,
    title character varying(255) DEFAULT NULL::character varying,
    content text,
    id integer NOT NULL
);


ALTER TABLE public.lmb_cms_text_block OWNER TO mail4testy;

--
-- Name: lmb_cms_text_block_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE lmb_cms_text_block_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lmb_cms_text_block_id_seq OWNER TO mail4testy;

--
-- Name: lmb_cms_text_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mail4testy
--

ALTER SEQUENCE lmb_cms_text_block_id_seq OWNED BY lmb_cms_text_block.id;


--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO mail4testy;

--
-- Name: lmb_cms_user; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE lmb_cms_user (
    id integer DEFAULT nextval('user_id_seq'::regclass) NOT NULL,
    email character varying(255) DEFAULT NULL::character varying,
    name character varying(255) DEFAULT NULL::character varying,
    hashed_password character varying(64) DEFAULT NULL::character varying,
    generated_password character varying(64) DEFAULT NULL::character varying,
    login character varying(50) DEFAULT NULL::character varying,
    role_type character varying(10) DEFAULT 0 NOT NULL,
    ctime integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.lmb_cms_user OWNER TO mail4testy;

--
-- Name: lmb_cms_user_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE lmb_cms_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lmb_cms_user_id_seq OWNER TO mail4testy;

--
-- Name: objoftree; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE objoftree (
    id integer NOT NULL,
    id_sys_tree integer,
    id_pr integer,
    value_pr character varying(32),
    is_branch integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.objoftree OWNER TO mail4testy;

--
-- Name: objoftree_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE objoftree_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.objoftree_id_seq OWNER TO mail4testy;

--
-- Name: objoftree_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mail4testy
--

ALTER SEQUENCE objoftree_id_seq OWNED BY objoftree.id;


--
-- Name: order; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE "order" (
    id integer DEFAULT nextval('user_id_seq'::regclass) NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    date integer DEFAULT 0 NOT NULL,
    summ double precision,
    status integer,
    address text
);


ALTER TABLE public."order" OWNER TO mail4testy;

--
-- Name: order_line; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE order_line (
    id integer DEFAULT nextval('user_id_seq'::regclass) NOT NULL,
    order_id integer DEFAULT 0 NOT NULL,
    product_id integer,
    quantity integer,
    price integer
);


ALTER TABLE public.order_line OWNER TO mail4testy;

--
-- Name: preference; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE preference (
    id integer NOT NULL,
    title character varying(32) NOT NULL,
    importance boolean DEFAULT false
);


ALTER TABLE public.preference OWNER TO mail4testy;

--
-- Name: TABLE preference; Type: COMMENT; Schema: public; Owner: mail4testy
--

COMMENT ON TABLE preference IS 'свойства / характеристики';


--
-- Name: preference_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE preference_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.preference_id_seq OWNER TO mail4testy;

--
-- Name: preference_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mail4testy
--

ALTER SEQUENCE preference_id_seq OWNED BY preference.id;


--
-- Name: product_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_id_seq OWNER TO mail4testy;

--
-- Name: product; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE product (
    id integer DEFAULT nextval('product_id_seq'::regclass) NOT NULL,
    title character varying(255) DEFAULT NULL::character varying,
    description text,
    is_available integer,
    price double precision,
    image_name character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public.product OWNER TO mail4testy;

--
-- Name: sys_session; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE sys_session (
    session_id character varying(50) DEFAULT ''::character varying NOT NULL,
    session_data bytea NOT NULL,
    last_activity_time bigint
);


ALTER TABLE public.sys_session OWNER TO mail4testy;

--
-- Name: sys_tree_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE sys_tree_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sys_tree_id_seq OWNER TO mail4testy;

--
-- Name: sys_tree; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE sys_tree (
    id integer DEFAULT nextval('sys_tree_id_seq'::regclass) NOT NULL,
    root_id integer DEFAULT 0 NOT NULL,
    parent_id integer DEFAULT 0 NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    level integer DEFAULT 0 NOT NULL,
    identifier character varying(128) DEFAULT ''::character varying NOT NULL,
    path character varying(255) DEFAULT ''::character varying NOT NULL,
    children integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.sys_tree OWNER TO mail4testy;

--
-- Name: tree_attribute; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE tree_attribute (
    title character varying(128) DEFAULT ''::character varying NOT NULL,
    is_published integer DEFAULT 0,
    id integer NOT NULL,
    is_field_system integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.tree_attribute OWNER TO mail4testy;

--
-- Name: tree_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE tree_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tree_attribute_id_seq OWNER TO mail4testy;

--
-- Name: tree_attribute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mail4testy
--

ALTER SEQUENCE tree_attribute_id_seq OWNED BY tree_attribute.id;


--
-- Name: tree_full; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE tree_full (
    id integer NOT NULL,
    root_id integer DEFAULT 0 NOT NULL,
    parent_id integer DEFAULT 0 NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    level integer DEFAULT 0 NOT NULL,
    path character varying(255) DEFAULT ''::character varying NOT NULL,
    children integer DEFAULT 0 NOT NULL,
    is_branch integer DEFAULT 0 NOT NULL,
    node_id integer DEFAULT 0 NOT NULL,
    identifier character varying(128) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.tree_full OWNER TO mail4testy;

--
-- Name: tree_full_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE tree_full_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tree_full_id_seq OWNER TO mail4testy;

--
-- Name: tree_full_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mail4testy
--

ALTER SEQUENCE tree_full_id_seq OWNED BY tree_full.id;


--
-- Name: tree_item; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE tree_item (
    id integer NOT NULL,
    node_id integer DEFAULT 0 NOT NULL,
    attr_id integer DEFAULT 0 NOT NULL,
    attr_value character varying(128) DEFAULT ''::character varying NOT NULL,
    is_branch integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.tree_item OWNER TO mail4testy;

--
-- Name: tree_item_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE tree_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tree_item_id_seq OWNER TO mail4testy;

--
-- Name: tree_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mail4testy
--

ALTER SEQUENCE tree_item_id_seq OWNED BY tree_item.id;


--
-- Name: tree_order; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE tree_order (
    user_id integer DEFAULT 0 NOT NULL,
    date integer DEFAULT 0 NOT NULL,
    summ double precision,
    status integer,
    address text,
    id integer NOT NULL
);


ALTER TABLE public.tree_order OWNER TO mail4testy;

--
-- Name: tree_order_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE tree_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tree_order_id_seq OWNER TO mail4testy;

--
-- Name: tree_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mail4testy
--

ALTER SEQUENCE tree_order_id_seq OWNED BY tree_order.id;


--
-- Name: tree_order_line; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE tree_order_line (
    order_id integer DEFAULT 0 NOT NULL,
    product_id integer,
    quantity integer,
    price integer,
    id integer NOT NULL
);


ALTER TABLE public.tree_order_line OWNER TO mail4testy;

--
-- Name: tree_order_line_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE tree_order_line_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tree_order_line_id_seq OWNER TO mail4testy;

--
-- Name: tree_order_line_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mail4testy
--

ALTER SEQUENCE tree_order_line_id_seq OWNED BY tree_order_line.id;


--
-- Name: tree_product; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE tree_product (
    id integer NOT NULL,
    title character varying(255) DEFAULT NULL::character varying,
    description text,
    is_available integer,
    price double precision,
    image_name character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public.tree_product OWNER TO mail4testy;

--
-- Name: tree_product_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE tree_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tree_product_id_seq OWNER TO mail4testy;

--
-- Name: tree_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mail4testy
--

ALTER SEQUENCE tree_product_id_seq OWNED BY tree_product.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE "user" (
    id integer DEFAULT nextval('user_id_seq'::regclass) NOT NULL,
    name character varying(255) DEFAULT NULL::character varying,
    login character varying(30) DEFAULT NULL::character varying,
    hashed_password character varying(32) DEFAULT NULL::character varying,
    email character varying(255) DEFAULT NULL::character varying,
    is_admin integer,
    address character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public."user" OWNER TO mail4testy;

--
-- Name: ware_id_seq; Type: SEQUENCE; Schema: public; Owner: mail4testy
--

CREATE SEQUENCE ware_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ware_id_seq OWNER TO mail4testy;

--
-- Name: ware; Type: TABLE; Schema: public; Owner: mail4testy; Tablespace: 
--

CREATE TABLE ware (
    id integer DEFAULT nextval('ware_id_seq'::regclass) NOT NULL,
    title character varying(255) DEFAULT NULL::character varying,
    description text,
    identifier character varying(128) DEFAULT ''::character varying NOT NULL,
    price double precision,
    date_created timestamp without time zone DEFAULT now() NOT NULL,
    date_modified timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ware OWNER TO mail4testy;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mail4testy
--

ALTER TABLE ONLY lmb_cms_document ALTER COLUMN id SET DEFAULT nextval('lmb_cms_document_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mail4testy
--

ALTER TABLE ONLY lmb_cms_seo ALTER COLUMN id SET DEFAULT nextval('lmb_cms_seo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mail4testy
--

ALTER TABLE ONLY lmb_cms_text_block ALTER COLUMN id SET DEFAULT nextval('lmb_cms_text_block_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mail4testy
--

ALTER TABLE ONLY objoftree ALTER COLUMN id SET DEFAULT nextval('objoftree_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mail4testy
--

ALTER TABLE ONLY preference ALTER COLUMN id SET DEFAULT nextval('preference_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mail4testy
--

ALTER TABLE ONLY tree_attribute ALTER COLUMN id SET DEFAULT nextval('tree_attribute_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mail4testy
--

ALTER TABLE ONLY tree_full ALTER COLUMN id SET DEFAULT nextval('tree_full_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mail4testy
--

ALTER TABLE ONLY tree_item ALTER COLUMN id SET DEFAULT nextval('tree_item_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mail4testy
--

ALTER TABLE ONLY tree_order ALTER COLUMN id SET DEFAULT nextval('tree_order_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mail4testy
--

ALTER TABLE ONLY tree_order_line ALTER COLUMN id SET DEFAULT nextval('tree_order_line_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: mail4testy
--

ALTER TABLE ONLY tree_product ALTER COLUMN id SET DEFAULT nextval('tree_product_id_seq'::regclass);


--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY category (id, title, descr, identifier, date_created, date_modified) FROM stdin;
\.
COPY category (id, title, descr, identifier, date_created, date_modified) FROM '$$PATH$$/2209.dat';

--
-- Name: category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('category_id_seq', 5, true);


--
-- Data for Name: lmb_cms_document; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY lmb_cms_document (title, description, keywords, content, is_published, parent_id, level, identifier, priority, path, ctime, utime, id) FROM stdin;
\.
COPY lmb_cms_document (title, description, keywords, content, is_published, parent_id, level, identifier, priority, path, ctime, utime, id) FROM '$$PATH$$/2210.dat';

--
-- Name: lmb_cms_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('lmb_cms_document_id_seq', 3, true);


--
-- Data for Name: lmb_cms_seo; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY lmb_cms_seo (url, title, description, keywords, id) FROM stdin;
\.
COPY lmb_cms_seo (url, title, description, keywords, id) FROM '$$PATH$$/2212.dat';

--
-- Name: lmb_cms_seo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('lmb_cms_seo_id_seq', 1, true);


--
-- Data for Name: lmb_cms_text_block; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY lmb_cms_text_block (identifier, title, content, id) FROM stdin;
\.
COPY lmb_cms_text_block (identifier, title, content, id) FROM '$$PATH$$/2214.dat';

--
-- Name: lmb_cms_text_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('lmb_cms_text_block_id_seq', 1, true);


--
-- Data for Name: lmb_cms_user; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY lmb_cms_user (id, email, name, hashed_password, generated_password, login, role_type, ctime) FROM stdin;
\.
COPY lmb_cms_user (id, email, name, hashed_password, generated_password, login, role_type, ctime) FROM '$$PATH$$/2217.dat';

--
-- Name: lmb_cms_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('lmb_cms_user_id_seq', 1, false);


--
-- Data for Name: objoftree; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY objoftree (id, id_sys_tree, id_pr, value_pr, is_branch) FROM stdin;
\.
COPY objoftree (id, id_sys_tree, id_pr, value_pr, is_branch) FROM '$$PATH$$/2219.dat';

--
-- Name: objoftree_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('objoftree_id_seq', 74, true);


--
-- Data for Name: order; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY "order" (id, user_id, date, summ, status, address) FROM stdin;
\.
COPY "order" (id, user_id, date, summ, status, address) FROM '$$PATH$$/2221.dat';

--
-- Data for Name: order_line; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY order_line (id, order_id, product_id, quantity, price) FROM stdin;
\.
COPY order_line (id, order_id, product_id, quantity, price) FROM '$$PATH$$/2222.dat';

--
-- Data for Name: preference; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY preference (id, title, importance) FROM stdin;
\.
COPY preference (id, title, importance) FROM '$$PATH$$/2223.dat';

--
-- Name: preference_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('preference_id_seq', 12, true);


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY product (id, title, description, is_available, price, image_name) FROM stdin;
\.
COPY product (id, title, description, is_available, price, image_name) FROM '$$PATH$$/2226.dat';

--
-- Name: product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('product_id_seq', 17, true);


--
-- Data for Name: sys_session; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY sys_session (session_id, session_data, last_activity_time) FROM stdin;
\.
COPY sys_session (session_id, session_data, last_activity_time) FROM '$$PATH$$/2227.dat';

--
-- Data for Name: sys_tree; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY sys_tree (id, root_id, parent_id, priority, level, identifier, path, children) FROM stdin;
\.
COPY sys_tree (id, root_id, parent_id, priority, level, identifier, path, children) FROM '$$PATH$$/2229.dat';

--
-- Name: sys_tree_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('sys_tree_id_seq', 1681, true);


--
-- Data for Name: tree_attribute; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY tree_attribute (title, is_published, id, is_field_system) FROM stdin;
\.
COPY tree_attribute (title, is_published, id, is_field_system) FROM '$$PATH$$/2230.dat';

--
-- Name: tree_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('tree_attribute_id_seq', 6, true);


--
-- Data for Name: tree_full; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY tree_full (id, root_id, parent_id, priority, level, path, children, is_branch, node_id, identifier) FROM stdin;
\.
COPY tree_full (id, root_id, parent_id, priority, level, path, children, is_branch, node_id, identifier) FROM '$$PATH$$/2232.dat';

--
-- Name: tree_full_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('tree_full_id_seq', 16, true);


--
-- Data for Name: tree_item; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY tree_item (id, node_id, attr_id, attr_value, is_branch) FROM stdin;
\.
COPY tree_item (id, node_id, attr_id, attr_value, is_branch) FROM '$$PATH$$/2234.dat';

--
-- Name: tree_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('tree_item_id_seq', 183, true);


--
-- Data for Name: tree_order; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY tree_order (user_id, date, summ, status, address, id) FROM stdin;
\.
COPY tree_order (user_id, date, summ, status, address, id) FROM '$$PATH$$/2236.dat';

--
-- Name: tree_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('tree_order_id_seq', 1, true);


--
-- Data for Name: tree_order_line; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY tree_order_line (order_id, product_id, quantity, price, id) FROM stdin;
\.
COPY tree_order_line (order_id, product_id, quantity, price, id) FROM '$$PATH$$/2238.dat';

--
-- Name: tree_order_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('tree_order_line_id_seq', 1, true);


--
-- Data for Name: tree_product; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY tree_product (id, title, description, is_available, price, image_name) FROM stdin;
\.
COPY tree_product (id, title, description, is_available, price, image_name) FROM '$$PATH$$/2240.dat';

--
-- Name: tree_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('tree_product_id_seq', 1, false);


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY "user" (id, name, login, hashed_password, email, is_admin, address) FROM stdin;
\.
COPY "user" (id, name, login, hashed_password, email, is_admin, address) FROM '$$PATH$$/2242.dat';

--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('user_id_seq', 23, true);


--
-- Data for Name: ware; Type: TABLE DATA; Schema: public; Owner: mail4testy
--

COPY ware (id, title, description, identifier, price, date_created, date_modified) FROM stdin;
\.
COPY ware (id, title, description, identifier, price, date_created, date_modified) FROM '$$PATH$$/2244.dat';

--
-- Name: ware_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mail4testy
--

SELECT pg_catalog.setval('ware_id_seq', 5, true);


--
-- Name: category_pkey; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- Name: id; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY preference
    ADD CONSTRAINT id PRIMARY KEY (id);


--
-- Name: lmb_cms_user_pkey; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY lmb_cms_user
    ADD CONSTRAINT lmb_cms_user_pkey PRIMARY KEY (id);


--
-- Name: objoftree_pkey; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY objoftree
    ADD CONSTRAINT objoftree_pkey PRIMARY KEY (id);


--
-- Name: order_line_pkey; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY order_line
    ADD CONSTRAINT order_line_pkey PRIMARY KEY (id);


--
-- Name: order_pkey; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY "order"
    ADD CONSTRAINT order_pkey PRIMARY KEY (id);


--
-- Name: product_pkey; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- Name: sys_session_pkey; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY sys_session
    ADD CONSTRAINT sys_session_pkey PRIMARY KEY (session_id);


--
-- Name: sys_tree_pkey; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY sys_tree
    ADD CONSTRAINT sys_tree_pkey PRIMARY KEY (id);


--
-- Name: tree_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY tree_attribute
    ADD CONSTRAINT tree_attribute_pkey PRIMARY KEY (id);


--
-- Name: tree_full_pkey; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY tree_full
    ADD CONSTRAINT tree_full_pkey PRIMARY KEY (id);


--
-- Name: tree_item_pkey; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY tree_item
    ADD CONSTRAINT tree_item_pkey PRIMARY KEY (id);


--
-- Name: tree_product_pkey; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY tree_product
    ADD CONSTRAINT tree_product_pkey PRIMARY KEY (id);


--
-- Name: user_pkey; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: ware_pkey; Type: CONSTRAINT; Schema: public; Owner: mail4testy; Tablespace: 
--

ALTER TABLE ONLY ware
    ADD CONSTRAINT ware_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: mail4testy
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM mail4testy;
GRANT ALL ON SCHEMA public TO mail4testy;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

